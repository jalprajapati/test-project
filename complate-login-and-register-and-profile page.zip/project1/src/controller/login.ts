import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import speakeasy from "speakeasy";
import { Request, Response } from "express";
import pool from "../config/config";
import console from "console";
import { Domain } from "domain";

require("dotenv").config();
class Loginuser {   
    public async Tokenverify_getuserdata(req:Request,res:Response):Promise<void>
      { 
        const token=req.cookies.userregisted;
        if (token == null) {
            res.redirect("/login")
          
        }else{
        jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
          if (err){
            res.clearCookie("userregisted");
            res.redirect("/login")
          }else{
            res.redirect("login");
        }
        });
        }}

      public async Login(req:Request,res:Response):Promise<void>
      {
            const useremail = req.body.useremail ;
            const userpass = req.body.userpassword ;
            const userotp = req.body.usereotp ;
            if (!useremail){ 
                 res.json("Enter email and password");
                }
            else{
              if(userpass && !userotp){

                pool.query("SELECT user_pass,user_email FROM loginuser WHERE user_email = ?",[useremail],async(err,Result)=> {
                  if(err) throw err;
                  if(Result.length === 0){
                    res.json("email is not match check your email right now!!!!")  
                  }         
                  if(Result.length != 0){
                    var hash= Result[0].user_pass;
                    bcrypt.compare(userpass,hash,(err,resu)=>{
                      if(err) throw err;
                      if(resu==false){
                        res.json("password is not match chech your password")  
                      }  
                      if(resu==true){
                        pool.query("SELECT * FROM loginuser WHERE user_email = ?",[useremail],(err:any,result:any)=>{
                          if(err)throw err;
                          else{
                            let jwtSecretKey = process.env.jwt_secret;
                            var token = jwt.sign({user_id : result[0].user_id}, jwtSecretKey|| "secret_key", { algorithm: 'HS256' });
                            
                            var exprie =process.env.cookie_expirs || "fhihsndhoihfhdoi";
                            const cookieoption={
                              expiresIn: new Date(Date.now()+exprie+(24*60*60*1000)),
                              httpOnly: true
                            }
                            res.cookie("userregisted",token, cookieoption)
                            res.redirect("dashboard")
                          }
                        })
                      }
                    })
                  }
                })
              }
              if(!userpass && userotp){
                pool.query("SELECT * FROM loginuser WHERE user_email = ?",[useremail],(err:any,result:any)=>{
                  if(err)throw err;
                  else{
                    console.log(result)
                    var verifued = speakeasy.totp.verify({
                        secret : result[0].secret_key ,
                        encoding: "base32",
                        token:userotp
                    })
                    console.log(userotp)
                    console.log(verifued)
                    if(verifued == true){
                      let jwtSecretKey = process.env.jwt_secret;
                      var token = jwt.sign({user_id : result[0].user_id}, jwtSecretKey|| "secret_key", { algorithm: 'HS256'});
                      console.log(token)
                      var exprie =process.env.cookie_expirs || "fhihsndhoihfhdoi";
                      const cookieoption={
                        expiresIn: new Date(Date.now()+100000),
                        httpOnly: true
                      }
                      res.cookie("userregisted",token, cookieoption)
                      res.redirect("dashboard")
                    }
                    
                    else{
                        res.send("OTP is not vaild")
                    }
                  }  
              })}
              
              if(!userpass && !userotp){
                 res.send("plases send password and otp any one")
              }
              }
            }
            }
const loginuser= new Loginuser();
export default loginuser;