import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import pool from "../config/config";

require("dotenv").config();

class Cookiejwtauth {    
      public async Tokenverify_getuserdata(req:Request,res:Response):Promise<void>
      { 
        const token=req.cookies.userregisted;
        if (token == null) {
            res.redirect("/login")
        }else{
        jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
          if (err){
            res.clearCookie("userregisted");
            res.redirect("/login")
          }else{
            pool.query("SELECT * FROM loginuser WHERE user_id = ?",[decoded.user_id],(err:any,result:any)=>{
              if(err)throw err;
              else{
                    res.send({result})  
              }  
        });}
        });
        }}
        
        public async Logout(req:Request,res:Response):Promise<void>{
          res.clearCookie("userregisted");
            res.redirect("/login");
        }
        
        public async userupdate(req:Request,res:Response):Promise<void>
        { 
          const token=req.cookies.userregisted;
          if (token == null) {
              res.redirect("/login")
            
          }else{
          jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
            if (err){
              res.clearCookie("userregisted");
              res.redirect("/login")
            }else{
              pool.query("SELECT * FROM loginuser WHERE user_id = ?",[decoded.user_id],(err:any,result:any)=>{
                if(err)throw err;
                else{   
                  // let jwtSecretKey = process.env.jwt_secret;
                  // var token1 = jwt.sign({user_id : result[0].user_id}, jwtSecretKey|| "secret_key", { algorithm: 'HS256' });
                  // console.log(token1)

                  // var exprie =process.env.cookie_expirs || "fhihsndhoihfhdoi";
                  // const cookieoption={
                  //       expiresIn: new Date(Date.now()+exprie+(24*60*60*1000)),
                  //       httpOnly: true
                  // }
                  // res.cookie("userupdated",token1, cookieoption)
                  // console.log("cookie",req.cookies.userupdated)
                  res.redirect("updatedata")  

                }  
          });}
          });
          }}
          public async dashborad(req:Request,res:Response):Promise<void>{
              res.redirect("dashboard");
          }
}

const cookiejwtauth= new Cookiejwtauth();
export default cookiejwtauth;