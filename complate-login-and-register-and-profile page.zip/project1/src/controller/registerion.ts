require('dotenv').config();
import bcrypt from "bcrypt";
import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import pool from "../config/config";


class Registionuser {    
      public async Registion(req:Request,res:Response):Promise<void>
      {
            const username = req.body.username ;
            const useremail = req.body.useremail ;
            const userpass = req.body.userpassword ;
            
            if(!useremail || !userpass ) {
                   res.json({ status:"error", error:"plases enter your email and password"}) 
            }
            else{
                  pool.query("SELECT COUNT(*) AS cnt FROM loginuser WHERE user_email = ? ",[useremail],(err,Result)=> {
                        if(err) throw err;
            
                        if(Result[0].cnt > 0){ 
                              res.send("email is allready exits check is not") 
                        }
                  
                        else{
                        const salt = bcrypt.genSaltSync(12).toString();
                        const pass =bcrypt.hashSync(userpass,salt).toString();
                        pool.query("INSERT INTO loginuser set user_name=?,user_email=?,user_pass=?",[username,useremail,pass],(error,results)=>{
                              if(error) throw error;
                              else{
                                    pool.query("SELECT * FROM loginuser WHERE user_email = ?",[useremail],(err:any,result:any)=>{
                                          if(err)throw err;
                                          else{

                                                let jwtSecretKey = process.env.jwt_secret;
                                                var token = jwt.sign({user_id : result[0].user_id}, jwtSecretKey|| "secret_key", { algorithm: 'HS256' });
                  
                                                var exprie =process.env.cookie_expirs || "fhihsndhoihfhdoi";
                                                const cookieoption={
                                                      expiresIn: new Date(Date.now()+exprie+(24*60*60*1000)),
                                                      httpOnly: true
                                                }
                                                res.cookie("userregisted",token, cookieoption)
                                                res.redirect("dashboard")               

                                                }
                                          })
                                          
                              }
                        })
                  }
                  })
    
            }
        
      } 
}
       

const registionuser= new Registionuser();
export default registionuser;
