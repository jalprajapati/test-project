import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import speakeasy from "speakeasy";
import qrcode from "qrcode";
import pool from "../config/config";

require("dotenv").config();

class two_auth {    
      public async Tokenverify_getuserdata(req:Request,res:Response):Promise<void>
      { 
        const token=req.cookies.userregisted;
        if (token == null) {
            res.redirect("/login")
          
        }else{
        jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
          if (err){
            res.clearCookie("userregisted");
            res.redirect("/login")
          }else{
            pool.query("SELECT * FROM loginuser WHERE user_id = ?",[decoded.user_id],(err:any,result:any)=>{
              if(err)throw err;
              else{
              
            var secret =speakeasy.generateSecret({})
            pool.query("UPDATE loginuser SET secret_key=? where user_id=?",[secret.base32,decoded.user_id],(err,Result)=>{
              if (err){
                throw err;
              }
              else{   
                qrcode.toDataURL(secret.otpauth_url || "uihfhhifnlsdfgflhfoig",(err,data)=>{
                  console.log(data)
                  res.json(data)
                })
              }

          })
        }
      });
    }
        })}
      }


}

const Two_auth= new two_auth();
export default Two_auth;
