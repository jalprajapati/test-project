import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import speakeasy from "speakeasy";
import qrcode from "qrcode";
import secret from "../controller/two_auth";
import pool from "../config/config";
require("dotenv").config();

class two_auth_verify {    
      public async Tokenverify_getuserdata(req:Request,res:Response):Promise<void>
      { 
        const token=req.cookies.userregisted;
        if (token == null) {
            res.redirect("/login")
          
        }else{
        jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
          if (err){
            res.clearCookie("userregisted");
            res.redirect("/login")
          }else{
            pool.query("SELECT * FROM loginuser WHERE user_id = ?",[decoded.user_id],(err:any,result:any)=>{
              if(err)throw err;
              else{
                console.log(result)
                var verifued = speakeasy.totp.verify({
                    secret : result[0].secret_key ,
                    encoding: "base32",
                    token:req.body.otpverify
                })
                console.log(req.body.otpverify)
                console.log(verifued)
                if(verifued == true){
                    res.redirect("dashboard")
                }
                else{
                    res.send("Otp rong")
                }
              }  
          })}
          })
        };
        }}
       

const Two_auth_verify= new two_auth_verify();
export default Two_auth_verify;