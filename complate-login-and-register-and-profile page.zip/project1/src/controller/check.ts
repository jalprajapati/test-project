import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import speakeasy from "speakeasy";
import qrcode from "qrcode";
import pool from "../config/config";

require("dotenv").config();

class two_ckeck {    
      public async Tokenverify_getuserdata(req:Request,res:Response):Promise<void>
      { 
        const token=req.cookies.userregisted;
        if (token == null) {
         res.redirect("/")
          
        }else{
        jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
          if (err){
            res.clearCookie("userregisted");
            res.redirect("/")
          }else{
            pool.query("SELECT * FROM loginuser WHERE user_id = ?",[decoded.user_id],(err:any,result:any)=>{
              if(err)throw err;
              else{
                console.log(result)
               console.log(result[0].is_2fa)
                if(result[0].is_2fa==0){
                    pool.query("UPDATE loginuser SET is_2fa = 1 where user_id =?",decoded.user_id,(err,Result)=>{
                        res.sendFile("2fa.html",{root:"public"})  
                    })
                }
                else{
                    pool.query("UPDATE loginuser SET is_2fa = 0,secret_key='null' where user_id =?",decoded.user_id,(err,Result)=>{
                      res.redirect("/")
                    })
                }
        }
      });
    }
})}
}


}

const Two_ckeck= new two_ckeck();
export default Two_ckeck;
