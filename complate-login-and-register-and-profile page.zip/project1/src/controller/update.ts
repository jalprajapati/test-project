import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import pool from "../config/config";
import bcrypt from "bcrypt";
import nodemailer from "nodemailer";
import mailservices from "../services/mail";
import Mail from "nodemailer/lib/mailer";
import { request } from "http";
require("dotenv").config();

class Updateuser { 
  public async Tokenverify_getuserdata(req:Request,res:Response):Promise<void>
  { 
    console.log("hiihiihi")
    const token=req.cookies.userregisted;
    if (token == null) {
      res.send({code:403,msg:"token is not found"}) 
      
    }else{
    jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
      if (err){
        res.clearCookie("userupdated");
        res.send({code:403,msg:"token is not vaild"})  
      }else{
        const username = req.body.username ;
        const curntpass =req.body.currentpassword;
        const newpass = req.body.newpassword ;
        const cnftnewrpass = req.body.cnfnewpassword ;
        
        if(username != '' && newpass!='' && cnftnewrpass!='' && curntpass!=''){
          pool.query("select * from loginuser where user_id=?",[decoded.user_id],(err,result2)=>{
            if (err){
              throw err;
            }
            else{
              console.log(result2)
              var hash= result2[0].user_pass;
              console.log(result2[0].user_pass);
              bcrypt.compare(curntpass,hash,(err,resu)=>{
                if(err) throw err;
                if(resu==false){
                  res.send("password is not match chech your password")  
                }  
                if(resu==true){
                  if(newpass==cnftnewrpass){
                   const salt = bcrypt.genSaltSync(12).toString();
                   const pass =bcrypt.hashSync(newpass,salt).toString();
                     pool.query("UPDATE loginuser SET user_name = ?, user_pass =? where user_id=?",[username,pass,decoded.user_id],(err,Result)=>{
                       if (err){
                         throw err;
                       }
                       else{
                         res.redirect("dashboard")       
                       }
                     })}
                     else{
                       res.send("new pass and cnft pass is not match");
                     }
                       }
                    })
                }})
            }
        else if(username == '' && newpass!='' && cnftnewrpass!='' && curntpass!=''){
          pool.query("select * from loginuser where user_id=?",[decoded.user_id],(err,result2)=>{
            if (err){
              throw err;
            }
            else{
              console.log(result2)
              var hash= result2[0].user_pass;
              console.log(result2[0].user_pass);
              bcrypt.compare(curntpass,hash,(err,resu)=>{
                if(err) throw err;
                if(resu==false){
                  res.send(" old password is not match chech your password")  
                }  
                if(resu==true){
                  if(newpass==cnftnewrpass){
                   const salt = bcrypt.genSaltSync(12).toString();
                   const pass =bcrypt.hashSync(newpass,salt).toString();
                     pool.query("UPDATE loginuser SET user_pass =? where user_id=?",[pass,decoded.user_id],(err,result)=>{
                       if (err){
                         throw err;
                       }
                       else{
                         res.redirect("dashboard")       
                       }
                     })}
                     else{
                       res.send("new pass and cnft pass is not match");
                     }
               }
                    })
                }})
            }
        else if(username != '' && newpass=='' && cnftnewrpass=='' && curntpass==''){
          pool.query("select * from loginuser where user_id=?",[decoded.user_id],(err,result2)=>{
            if (err){
              throw err;
            }
            else{
                pool.query("UPDATE loginuser SET user_name =? where user_id=? ",[username,decoded.user_id],(err,Result)=>{
                  if (err){
                    throw err;
                  }
                  else{
                    console.log("abcdefg"+123)
                        res.redirect("dashboard")      
                      }
                  })
                }
                })}
        else{
              res.send("something not right")
          }
        }
      }  
    )}
  }
}

const updateuser= new Updateuser();
export default updateuser;

