import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import nodemailer from "nodemailer";
import { decode } from "punycode";
import pool from "../config/config";
require("dotenv").config();

class Mailservices { 
  public async getmail(req:Request,res:Response):Promise<void>
  { 
    const token=req.cookies.userupdated;
    if (token == null) {
      res.redirect("dashboard")}
    else{
        jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
            if (err){
                res.clearCookie("userupdated");
                res.redirect("dashboard")}
            else{     
                console.log(decoded)         
                const transporter = nodemailer.createTransport({
                service: "gmail",
                auth: {
                user: "jalpeshp922@gmail.com",
                pass: "maavgrjwwxvufmuy",}});

                console.log(decoded[0].user_email)
                const information={  
                    from:'jalpeshp922@gmail.com',
                    to :decoded[0].user_email,
                    subject: "update sucessfully",
                    text: "update successfly",};
                
                    transporter.sendMail(information,(err, info)=>{console.log("sent");})
                }
            })
        }            
    }
}
const mailservices= new Mailservices();
export default mailservices;

