import cors from "cors";
import { Router } from "express";
import cookiejwtauth from "../controller/dashborad";
import loginuser from "../controller/login";
import registionuser from "../controller/registerion";
import updateuser from "../controller/update";
// import Chechtoken from "../controller/tokenverify";
import Two_auth from "../controller/two_auth";
import Two_auth_verify from "../controller/two_auth_verify";
import Two_ckeck from "../controller/check";
import Chechtoken from "../middleware/verify";




class IndexRoutes{
  public router:Router=Router();
  
  constructor(){
    this.config();
  }
  config():void{
    this.router.use(cors());
    this.router.get("/",Chechtoken.isverify,(req,res)=>{res.sendFile("index.html",{root:"public"})})  //res.sendFile("index.html",{root:"public"})
    
    this.router.get("/login",Chechtoken.isverify,(req,res)=>{res.sendFile("login.html",{root:"public"})})// res.sendFile("login.html",{root:"public"}) 
    this.router.post("/login",loginuser.Login);
    
    this.router.get("/register",Chechtoken.isverify,(req,res)=>{res.sendFile("register.html",{root:"public"})}) //res.sendFile("register.html",{root:"public"}) 
    this.router.post("/register",registionuser.Registion);
    
    
    this.router.get("/dashboard",Chechtoken.isnotverify,(req,res)=>{res.sendFile("deshbord.html",{root:"public"})}) //res.sendFile("deshbord.html",{root:"public"})
  
    this.router.get("/profile",cookiejwtauth.Tokenverify_getuserdata);//send user data
    this.router.post("/profile",cookiejwtauth.Logout); 
   
    this.router.post("/dashboard",cookiejwtauth.dashborad); //res.redirct("dashborad")
   
    this.router.get("/authation",Chechtoken.isnotverify,(req,res)=>{res.sendFile("2fa.html",{root:"public"})}) //res.sendFile("2fa.html",{root:"public"})
    this.router.get("/auth",Two_auth.Tokenverify_getuserdata); //send barcode data
    
    this.router.get("/profile/2fa",Chechtoken.isnotverify,(req,res)=>{res.sendFile("2fa.html",{root:"public"})}) // check 2fa on or off
    this.router.post("/profile/2fa",Two_ckeck.Tokenverify_getuserdata)// change 2fa on 
    this.router.post("/auth",Two_auth_verify.Tokenverify_getuserdata)
    
    this.router.get("/updatedata",Chechtoken.isnotverify,(req,res)=>{res.sendFile("update.html",{root:"public"})}) //  res.sendFile("update.html",{root:"public"})
    // this.router.get("/update",Chechtoken.updateTokenverify) //res.sendFile("update.html",{root:"public"})
    
    this.router.get("/update",cookiejwtauth.userupdate);
    this.router.post("/update",updateuser.Tokenverify_getuserdata)     
    // this.router.get("/**",Chechtoken.isnotverify)
  }
}
const indexrouter= new IndexRoutes();
export default indexrouter.router;