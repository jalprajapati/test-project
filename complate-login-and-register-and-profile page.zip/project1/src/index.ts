import express, { Application } from "express";
import indexroute  from "./route/indexroute";
import bodyParser from "body-parser";
import cookie from "cookie-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
class server{
  public app:Application;

  constructor(){
    this.app=express();
    this.confing();
    this.route();
  }
  confing(): void{
    this.app.set('port',process.env.port ||5000);

  }
  route():void{
    this.app.use(bodyParser.urlencoded({extended:false}))
    this.app.use(bodyParser.json())
    
    this.app.use(express.json());
    this.app.use(express.urlencoded({extended: true}));
    
    this.app.use(cookie());
    this.app.use(cookieParser());
    
    this.app.use(cors());
    this.app.use(indexroute);
  }
  start():void{
    this.app.listen(this.app.get('port'),()=>{
      console.log(`server on port`,this.app.get('port'))
    })
  }
}
const Server =new server();
Server.start();