import { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import pool from "../config/config";
class chechtoken {  
  public async isverify(req:Request,res:Response,next:NextFunction):Promise<void>
        { 
          const token=req.cookies.userregisted;
          if (token == null) {
            next()}
          else{
          jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
            if (err){
              res.clearCookie("userregisted");
              next()}
            else{
                  res.redirect("dashboard")}
              });
            }
    }

public async isnotverify(req:Request,res:Response,next:NextFunction):Promise<void>
        { 
          const token=req.cookies.userregisted;
          if (token == null) {
            console.log(req.url)
            if(req.url=="/dashboard" || req.url =="/updatedata" || req.url =="/updatedata" || req.url == "/profile/2fa" || req.url==req.url){
                res.clearCookie("userregisted")
                res.redirect("/")}
            else{
                res.redirect(req.url)
            }
            }
          else{
          jwt.verify(token ,process.env.jwt_secret || "secret_key", function(err:any, decoded:any   ) {
            if (err){   
                if(req.url=="/dashboard" || req.url =="/updatedata" || req.url =="/updatedata" || req.url == "/profile/2fa"|| req.url==req.url){
                    res.clearCookie("userregisted")
                    res.redirect("/")}
                else{
                    res.redirect(req.url)
                    }}
            else{
                 next()}
              });
            }
    }
}
const Chechtoken= new chechtoken();
export default Chechtoken;